---
title: micro4 terugkijken en vooruit
niveau: A0–A2
duur: 25
license: CC-BY-SA-4.0
---

### 🌟 Start (5 min)
[Intro met beeld/audio/vraag]

### 🔑 Kern (15 min)
[Dialoog/tekst + oefening + mini-taak]

### ✅ Check-out (5 min)
[Reflectievraag of minitest]
