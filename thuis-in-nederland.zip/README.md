# 🇳🇱 Thuis in Nederland — De Modulaire NT2-Methode

Deze repository bevat de volledige OER-structuur voor de modulaire methode **Thuis in Nederland**.
- Microlearning (25-min lessen)
- Scenario’s + Taalhandelingen + Taalvormen + Differentiatie
- Grammatica-matrix A0–C2
- Open licentie (CC BY-SA 4.0)

Zie `/templates` voor officiële sjablonen.
