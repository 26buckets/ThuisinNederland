---
title: [TITEL INVOEGEN]
niveau: [A2]
categorie: [Werkwoorden/Zinsstructuur/Voornaamwoorden/etc.]
license: CC-BY-SA-4.0
---

## Uitleg
[Beschrijf de kernregel.]

## Voorbeelden
- ...

## Oefening
1. ...
2. ...
