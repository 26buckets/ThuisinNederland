---
title: [TITEL SCENARIO]
scenario_id: [thema_scenarioXX]
niveau: [Alfa/A1/A2/B1/B2/C1/C2]
thema: [Werk/Gezondheid/Wonen/Vrije tijd/School/Maatschappij]
duur: 25-50
erk: [A1.1 etc.]
taalhandelingen:
  - [beschrijf wat de cursist kan]
grammatica:
  - [koppel aan /grammatica/ bestanden]
differentiatie:
  - Alfa: beeld + audio
  - A1–A2: tekst + invul
  - B1+: reflectie
license: CC-BY-SA-4.0
---

## 1. Situatie
[Korte context, 2–3 zinnen]

## 2. Dialoog of tekst
[10–15 beurten of korte tekst]

## 3. Begrip
- Vraag 1
- Vraag 2

## 4. Taalhandelingen
| Functie | Voorbeeld |
|---------|-----------|
|         |           |

## 5. Taak
[Rol A / Rol B – praktische opdracht]

## 6. Reflectie
[Wat zeg jij in jouw situatie?]
